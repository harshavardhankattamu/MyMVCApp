package com.example.OrderService.service;

import com.example.OrderService.client.InventoryServiceClient;
import com.example.OrderService.client.ProductServiceClient;
import com.example.OrderService.dto.ProductResponseDTO;
import com.example.OrderService.dto.UpdateQuantityRequestDTO;
import com.example.OrderService.dto.VendorProductResponse;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

@Service
public class InventoryService {
    private final InventoryServiceClient inventoryServiceClient;

    public InventoryService(InventoryServiceClient inventoryServiceClient) {
        this.inventoryServiceClient = inventoryServiceClient;
    }

    public VendorProductResponse getVendorProduct(Long id,String authToken) {
        return inventoryServiceClient.getVendorProduct(id,authToken);
    }
    public VendorProductResponse updateReserveQuantityById(Long id, UpdateQuantityRequestDTO requestDTO, String authToken) {
        return inventoryServiceClient.updateReserveQuantityById(id,requestDTO,authToken);
    }
    public VendorProductResponse updateQuantityById(Long id, UpdateQuantityRequestDTO requestDTO, String authToken) {
        return inventoryServiceClient.updateQuantityById(id,requestDTO,authToken);
    }
    public VendorProductResponse releaseReserveQuantityById(Long id, UpdateQuantityRequestDTO requestDTO, String authToken) {
        return inventoryServiceClient.releaseReserveQuantityById(id,requestDTO,authToken);
    }
    public VendorProductResponse releaseProductByReserveQuantity(Long id, UpdateQuantityRequestDTO requestDTO, String authToken) {
        return inventoryServiceClient.releaseProductByReserveQuantity(id,requestDTO,authToken);
    }
}
