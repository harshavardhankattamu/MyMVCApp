package com.example.OrderService.service;


import com.example.OrderService.dto.OrderItemDTO;
import com.example.OrderService.dto.ProductResponseDTO;
import com.example.OrderService.dto.UpdateQuantityRequestDTO;
import com.example.OrderService.dto.VendorProductResponse;
import com.example.OrderService.exception.NotFoundException;
import com.example.OrderService.model.Order;
import com.example.OrderService.model.OrderItem;
import com.example.OrderService.model.OrderStatus;
import com.example.OrderService.repository.OrderItemRepository;
import com.example.OrderService.repository.OrderRepository;
import feign.FeignException;
import jakarta.validation.Valid;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Objects;


@Service
public class OrderService {
    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final ProductService productService;
    private final InventoryService inventoryService;

    public OrderService(OrderRepository orderRepository,OrderItemRepository orderItemRepository,ProductService productService,InventoryService inventoryService){
        this.orderRepository=orderRepository;
        this.orderItemRepository=orderItemRepository;
        this.productService=productService;
        this.inventoryService=inventoryService;
    }

    @Transactional
    public Order generateOrder(Long userId, @Valid List<OrderItemDTO> orderItems, String authToken) throws NotFoundException {

        Order order = new Order();
        order.setUserId(userId);
        order.setStatus(OrderStatus.CREATED);

        double totalAmount = 0;
        for (OrderItemDTO item : orderItems) {
            VendorProductResponse vendorProductResponse;
            try {
                vendorProductResponse=inventoryService.getVendorProduct(item.getStockId(),authToken);
            } catch (FeignException.NotFound ex) {
                throw new NotFoundException("Stock not found with id: " + item.getStockId());
            }

            OrderItem orderItem = new OrderItem();
            orderItem.setProductId(vendorProductResponse.getProductId());
            orderItem.setQuantity(item.getQuantity());
            orderItem.setPrice(vendorProductResponse.getPrice());
            orderItem.setDiscount(vendorProductResponse.getDiscount());

            double discountedUnitPrice = vendorProductResponse.getPrice() - (vendorProductResponse.getPrice() * vendorProductResponse.getDiscount() / 100);

            double finalPrice = discountedUnitPrice * item.getQuantity();

            orderItem.setFinalPrice(finalPrice);

            order.addOrderItem(orderItem);

            totalAmount += finalPrice;
        }

        order.setTotalAmount(totalAmount);
        order.setStatus(OrderStatus.CREATED);
        order.setUpdatedAt(Instant.now());

        return orderRepository.save(order);
    }

    public Order getOrderById(Long id) throws NotFoundException {
        return orderRepository.findById(id)
                .orElseThrow(() -> new NotFoundException(
                        "Order not found with id: " + id
                ));
    }


    public void deleteOrder(Long id) throws NotFoundException {
        if (!orderRepository.existsById(id)) {
            throw new NotFoundException("Order not found with id: " + id);
        }
        orderRepository.deleteById(id);
    }

    public Order reserveOrder(Long userId,Long orderId,List<OrderItemDTO> orderItemDTOList, String authToken) throws NotFoundException {
        Order order=this.getOrderById(orderId);
        if(!Objects.equals(order.getUserId(), userId)){
            throw new NotFoundException("Order with user Id not found");
        }
        for (OrderItemDTO item : orderItemDTOList) {
            VendorProductResponse vendorProductResponse;
            try {
                vendorProductResponse=inventoryService.updateReserveQuantityById(item.getStockId(),new UpdateQuantityRequestDTO(item.getQuantity()),authToken);
            } catch (FeignException ex) {
                throw new NotFoundException(ex.getMessage());
            }
        }
        order.setStatus(OrderStatus.PAYMENT_INITIATED);
        order.setUpdatedAt(Instant.now());
        return orderRepository.save(order);
    }

    public Order placeOrder(Long userId,Long orderId,List<OrderItemDTO> orderItemDTOList, String authToken) throws NotFoundException {
        Order order=this.getOrderById(orderId);
        if(!Objects.equals(order.getUserId(), userId)){
            throw new NotFoundException("Order with user Id not found");
        }
        for (OrderItemDTO item : orderItemDTOList) {
            VendorProductResponse vendorProductResponse;
            try {
                vendorProductResponse=inventoryService.updateQuantityById(item.getStockId(),new UpdateQuantityRequestDTO(item.getQuantity()),authToken);
            } catch (FeignException ex) {
                throw new NotFoundException("Stock not found with id: " + item.getStockId());
            }
        }
        order.setStatus(OrderStatus.CONFIRMED);
        order.setUpdatedAt(Instant.now());
        return orderRepository.save(order);
    }

    public Order placeOrderFailed(Long userId,Long orderId,List<OrderItemDTO> orderItemDTOList, String authToken) throws NotFoundException {
        Order order=this.getOrderById(orderId);
        if(!Objects.equals(order.getUserId(), userId)){
            throw new NotFoundException("Order with user Id not found");
        }
        if(order.getStatus()==OrderStatus.CONFIRMED){
            throw  new NotFoundException("Order already confirmed");
        }
        if(order.getStatus()==OrderStatus.FAILED){
            throw new NotFoundException("Order has been failed");
        }
        for (OrderItemDTO item : orderItemDTOList) {
            VendorProductResponse vendorProductResponse;
            try {
                vendorProductResponse=inventoryService.releaseProductByReserveQuantity(item.getStockId(),new UpdateQuantityRequestDTO(item.getQuantity()),authToken);
            } catch (FeignException ex) {
                throw new NotFoundException(ex.getMessage());
            }
        }
        order.setStatus(OrderStatus.FAILED);
        order.setUpdatedAt(Instant.now());
        return orderRepository.save(order);
    }
}
